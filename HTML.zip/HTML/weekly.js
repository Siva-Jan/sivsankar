function onformsubmit(){
var formdata = readformdata();
insertNewrecord(formdata);

}

function readformdata(){
  var formdata={};
  formdata["DATE"] =document.getElementById("DATE").value;
  formdata["SHIFT"] =document.getElementById("SHIFT").value;
  formdata["PROJECT"] =document.getElementById("PROJECT").value;
  formdata["EMAIL_SUBJECT"] =document.getElementById("EMAIL_SUBJECT").value;
  formdata["TEAM"] =document.getElementById("TEAM").value;
  formdata["RECEIVED_TIME"] =document.getElementById("RECEIVED_TIME").value;
  formdata["RESPONSE_TIME"] =document.getElementById("RESPONSE_TIME").value;
  formdata["EMAILID"] =document.getElementById("EMAILID").value;
  formdata["TYPE"] =document.getElementById("TYPE").value;
  formdata["SFIS_SHIFT_INCHARGE"] =document.getElementById("SFIS_SHIFT_INCHARGE").value;
  formdata["RESOLUTION"] =document.getElementById("RESOLUTION").value;
  formdata["SOP/EMAIL"] =document.getElementById("SOP/EMAIL").value;
  formdata["STATUS"] =document.getElementById("STATUS").value;
  formdata["COUNTERPART_SUPPORT"] =document.getElementById("COUNTERPART_SUPPORT").value;
  return formdata;
}

function insertNewrecord(data){
  var table=document.getElementById("WEEKLYREPORT").getElementsByTagName('tbody')[0];
  var newrow = table.insertRow(table.length);
  cell1 = newrow.insertCell(0);
  cell1.innerHTML = data.DATE;
  cell2 = newrow.insertCell(1);
  cell2.innerHTML = data.SHIFT;
  cell3 = newrow.insertCell(2);
  cell3.innerHTML = data.PROJECT;
  cell4 = newrow.insertCell(3);
  cell4.innerHTML = data.EMAIL_SUBJECT;
  cell5 = newrow.insertCell(4);
  cell5.innerHTML = data.TEAM;
  cell6 = newrow.insertCell(5);
  cell6.innerHTML = data.RECEIVED_TIME;
  cell7 = newrow.insertCell(6);
  cell7.innerHTML = data.RESPONSE_TIME;
  cell8 = newrow.insertCell(7);
  cell8.innerHTML = data.EMAILID;
  cell9 = newrow.insertCell(8);
  cell9.innerHTML = data.TYPE;
  cell10 = newrow.insertCell(9);
  cell10.innerHTML = data.SFIS_SHIFT_INCHARGE;
  cell11 = newrow.insertCell(10);
  cell11.innerHTML = data.RESOLUTION;
  cell12 = newrow.insertCell(11);
  cell12.innerHTML = data.SOP/EMAIL;
  cell13 = newrow.insertCell(12);
  cell13.innerHTML = data.STATUS;
  cell14 = newrow.insertCell(13);
  cell14.innerHTML = data.COUNTERPART_SUPPORT;
  cell14 = newrow.insertCell(13);
  cell14.innerHTML = `<a>Edit</a>
                       <a>Delete</a>`; 


}